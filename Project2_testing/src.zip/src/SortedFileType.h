/*
 * SortedFileType.h
 *
 *  Created on: Mar 8, 2013
 *      Author: gaurab
 */

#ifndef SORTEDFILETYPE_H_
#define SORTEDFILETYPE_H_
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <string>

#include "TwoWayList.h"
#include "Record.h"
#include "Schema.h"
#include "File.h"
#include "Comparison.h"
#include "ComparisonEngine.h"
#include "Defs.h"
#include "BigQ.h"
#include "Pipe.h"
//
#include "GenericDBFile.h"

struct SortInfoDB
{
    OrderMaker *myOrder;
    int runLength;
};

class SortedFileType :public GenericDBFile{
public:
	SortedFileType();
	~SortedFileType();
	// DB file functions moved here //
	int Create (char *fpath,fType file_type,void *startup);
	int Open (char *fpath);
	int Close ();
	void Load (Schema &myschema, char *loadpath);
	void MoveFirst ();
	void Add (Record &addme);
	int GetNext (Record &fetchme);
	int GetNext (Record &fetchme, CNF &cnf, Record &literal);

	// Reading / writing in the metafile
	void ReadMetaData(char *f_path);
	void WriteMetaData(char* f_path, char* f_type, void* startup);


private:
	// Get record from sorted file to merge with pipe //
	int GetRecord (Record &fetchme, Page &page);

	// Add the record to the temporary page //
	void AddRecord (Record& rec);

	// Merge The records into a pipe //
	void Merge(Pipe* out);

	// Compare, return 0 if lhs < rhs else returns 1//
	int Compare(Record* lhs, Record* rhs);

	Pipe *input;
	Pipe *output;

	File tempfile;
	BigQ *bigQ;

	Mode mode;

	off_t temppnum;
	off_t pnumber;

	Page tempp;

	bool currentlyMerging;

	static const int PIPE_SIZE = 100;

};


#endif /* SORTEDFILETYPE_H_ */
