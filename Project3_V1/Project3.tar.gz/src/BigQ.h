#ifndef BIGQ_H
#define BIGQ_H
#include <pthread.h>
#include <iostream>
#include "Pipe.h"
#include "File.h"
#include "Record.h"
#include <queue>
#include <vector>

using namespace std;

class BigQ {
    
    private:
        
        int compareRecords(Record *record1, Record *record2);
        void generateRuns();
        void doSorting(Page pages[]);
        void mergeRecords();
        int runCount;
        int runlength;
        int pageCount;        
        Pipe* inputPipe;
        Pipe* outputPipe;
        vector<int>* runPages;
        OrderMaker *order;
        Schema *schema;
        char tempFileName[40];
    public:
	BigQ (Pipe &in, Pipe &out, OrderMaker &sortorder, int runlen);
        BigQ (Pipe &in, Pipe &out, OrderMaker &sortorder, int runlen, bool val);
        static void* executeWorkerThread(void * ptr);
	virtual ~BigQ ();
    

};

class CompareRecords {
    private:
        OrderMaker *sortOrder;
        bool direction;
    
    public:
        
        CompareRecords(OrderMaker *orderMaker , bool dir) {
            this->sortOrder = orderMaker;
            this->direction = dir;
        }
        CompareRecords(){};
    bool operator()(Record *record1, Record *record2) {
        int result = 0;
        ComparisonEngine *compEng;
        
        if(direction)
                result = compEng->Compare(record1, record2, sortOrder);
        else
                result = compEng->Compare(record2, record1, sortOrder);
        
        if(result == -1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
};



#endif
