#include "RelationalOp.h"
#include "stdlib.h"
#include "DuplicateRemoval.h"


DuplicateRemoval::DuplicateRemoval(){
    this->pages = 25;
}

void DuplicateRemoval::Run (Pipe &inPipe, Pipe &outPipe, Schema &mySchema) { 
    this->inputPipe = &inPipe;
    this->outputPipe = &outPipe;
    this->schema = & mySchema;
    pthread_create (&thread, NULL, &executeWorkerThread, (void*)this);
}

 void* DuplicateRemoval::executeWorkerThread(void * ptr){
   DuplicateRemoval* DR = reinterpret_cast<DuplicateRemoval*> (ptr); 
   Pipe*  sortedPipe = new Pipe(100);
   OrderMaker sortOrder(DR->schema);
   
   // sort the incoming tuples
   BigQ* bigQ = new BigQ(*(DR->inputPipe), *sortedPipe, sortOrder, DR->pages);
   
   Record rec;
   Record prevRec , prevRecCopy;   
   ComparisonEngine compEng;
   if(sortedPipe->Remove(&prevRec)){
       prevRecCopy.Copy(&prevRec);
       DR->outputPipe->Insert(&prevRecCopy);
   }
      
   while(sortedPipe->Remove(&rec)){       
       /* if the records are equal then skip them        
        else push the new record into the output pipe and update the prev record
        */
       if(compEng.Compare(&rec, &prevRec, &sortOrder) != 0){
           prevRec.Copy(&rec);
           DR->outputPipe->Insert(&rec);
       }
   }
   DR->outputPipe->ShutDown();
   delete bigQ;
}
 
 
void DuplicateRemoval::WaitUntilDone () { 
    pthread_join (thread, NULL);
}
void DuplicateRemoval::Use_n_Pages (int n) { 
    this->pages = n;
}

