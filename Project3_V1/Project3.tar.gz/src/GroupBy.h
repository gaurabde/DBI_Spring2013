#ifndef GROUPBY_H
#define GROUPBY_H

#include "Pipe.h"
#include "DBFile.h"
#include "Record.h"
#include "Function.h"
#include "BigQ.h"
#include <iostream>
#include <sstream>

class GroupBy : public RelationalOp {
        private:
                pthread_t thread;
                Pipe* inputPipe;
                Pipe* outputPipe;
                OrderMaker* groupByAtts;
                int pages;
                Function* sumFunction;
                static void* executeWorkerThread(void * ptr);  
                void generateSumRecord(Type& resultType , long long int* intSum , long double* doubleSum , char* sumOutput , Record* outputRecord ,  Schema* outputSchema);
        
        public:
                GroupBy();
                void Run (Pipe &inPipe, Pipe &outPipe, OrderMaker &groupAtts, Function &computeMe);
                void WaitUntilDone ();
                void Use_n_Pages (int n);
};
#endif
