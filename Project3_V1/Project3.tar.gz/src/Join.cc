#include "RelationalOp.h"
#include "stdlib.h"
#include "Join.h"

Join::Join(){
    this->runLength = 25;
}


void Join::Run(Pipe &inPipeL, Pipe &inPipeR, Pipe &outPipe, CNF &selOp, Record &literal) {
    this->inPipeL = &inPipeL;
    this->inPipeR = &inPipeR;
    this->outPipe = &outPipe;
    this->selOp = &selOp;
    this->literal = &literal;
    pthread_create (&thread, NULL, &executeWorkerThread, (void*)this);
}

void* Join::executeWorkerThread(void * ptr) {
    Join *join = reinterpret_cast<Join*> (ptr);
    if (join->selOp->GetSortOrders(join->leftOrderMaker, join->rightOrderMaker) == 1) {
        //Do a sort-merge join.
        join->doSortMergeJoin(join);
    } else {
        //Do a block-nested join - All with all combinations.
        join->doBlockNestedJoin(join);
    }
    
    join->outPipe->ShutDown();
    cout << "join done" << endl;
}

void Join::WaitUntilDone() {
    pthread_join (thread, NULL);
}

void Join::Use_n_Pages(int n) {
    this->runLength = n;
}
void Join::doBlockNestedJoin(Join *join) {
    rightFile.Open(0, "temp-db-right-file.bin");
    pageCounter = 0;
    totalNoOfPages = 0;
    rightFileCreated = false;
    Page *page;
    Record lastRecord;
    
    blockPage = new Page();
    page = fetchNextBlock(join, lastRecord);
    blockPage = new Page();
    blockPage->Append(&lastRecord);
    Record leftRecord;
    Record rightRecord;
    ComparisonEngine comp;
    
    bool firstRun = true;
    int leftNumAtts;
    int rightNumAtts;
    int numJoinAttributes;
    int startOfRightLocation = 0;
    int *joinAttributes;
    endOfBlocks = false;
        
    while (join->inPipeL->Remove(&leftRecord) == 1) {
        while (!endOfBlocks) {
            while (page->GetFirst(&rightRecord)) {
                if (comp.Compare(&leftRecord, &rightRecord, join->literal, join->selOp) == 1) {

                    if (firstRun) {
                        //Construct the merge parameters.
                        //Construct the joinAttributes.
                        leftNumAtts = leftRecord.GetNumOfAttributes();
                        rightNumAtts = rightRecord.GetNumOfAttributes();
                        numJoinAttributes = leftNumAtts + rightNumAtts;
                        joinAttributes = new int[numJoinAttributes];
                        int i;
                        int count = 0;
                        for(i = 0; i < leftNumAtts; i++) {
                            joinAttributes[count++] = i;
                        }
                        startOfRightLocation = count;
                        for(i = 0;i < rightNumAtts; i++) {
                            joinAttributes[count++] = i;
                        }
                    }
                    
                    firstRun = false;
                    Record joinRecord;
                    joinRecord.MergeRecords(&leftRecord, &rightRecord, leftNumAtts, rightNumAtts, joinAttributes, numJoinAttributes, startOfRightLocation);
                      join->outPipe->Insert(&joinRecord); 
                    
                }
            } 
                   
            Record lastRecord;
            page = fetchNextBlock(join, lastRecord);
            if (lastRecord.bits != NULL) {
                //cout << "not null here" << endl;
                blockPage->Append(&lastRecord);
                
                leftNumAtts = leftRecord.GetNumOfAttributes();
                rightNumAtts = rightRecord.GetNumOfAttributes();
                numJoinAttributes = leftNumAtts + rightNumAtts;
                joinAttributes = new int[numJoinAttributes];
                int i;
                int count = 0;
                for(i = 0; i < leftNumAtts; i++) {
                    joinAttributes[count++] = i;
                }
                startOfRightLocation = count;
                for(i = 0;i < rightNumAtts; i++) {
                    joinAttributes[count++] = i;
                }
                
                Record joinRecord;
                joinRecord.MergeRecords(&leftRecord, &lastRecord, leftNumAtts, rightNumAtts, joinAttributes, numJoinAttributes, startOfRightLocation);
                  join->outPipe->Insert(&joinRecord); 
            } 
        }
        
        endOfBlocks = false;
        rightFileCreated = true;
    }    
    
}

Page* Join::fetchNextBlock(Join *join, Record &lastRecord) {
    Record tempRecord;
    
    if (rightFileCreated) {
        if (pageCounter < totalNoOfPages) {
            rightFile.GetPage(blockPage, pageCounter);
            //cout << "page taken" << endl;
            //cout << "totalNoOfPages :: " << totalNoOfPages << endl;
            pageCounter++;
        } else {
            endOfBlocks = true;
            pageCounter = 0;
            Page *page = new Page();
            return page;
        }
    } else {
        if (totalNoOfPages == 0 || pageCounter < totalNoOfPages) {
           while (join->inPipeR->Remove(&tempRecord) == 1) {
                if (blockPage->Append(&tempRecord) == 1) {
                    lastPage = true;
                } else {
                    //Cannot be appended. Save the record.
                    lastRecord.Copy(&tempRecord);
                    rightFile.AddPage(blockPage, pageCounter);
                    pageCounter++;
                    lastPage = false;
                    break;
                }
            }

            if (lastPage) {
                rightFile.AddPage(blockPage, pageCounter);
                pageCounter++;
                totalNoOfPages = pageCounter;
                lastPage = false;               
            } 
        } else {
            pageCounter = 0;
            endOfBlocks = true;
            Page *page = new Page();
            return page;
        }
    }
     
    return blockPage;
}

void Join::doSortMergeJoin(Join *join) {        
        ComparisonEngine comp;
        
        Pipe *sortedRPipe = new Pipe(100);        
        BigQ *bigQL = new BigQ(*(join->inPipeR), *sortedRPipe, join->rightOrderMaker, join->runLength);
        Pipe *sortedLPipe = new Pipe(100);
        BigQ *bigQR = new BigQ(*(join->inPipeL), *sortedLPipe, join->leftOrderMaker, join->runLength);
        
        Record leftRec;
        Record rightRec;
        Record leftPrevRec;
        Record rightPrevRec;
        
        bool firstRun = true;
        bool lastRecordsMatched = false;
        bool leftGreater = false;
        bool leftAlreadyRemoved = false;
        
        Page* filePage = new Page();
        File file;
        char fileName[100]; // enough to hold all numbers up to 64-bits
        sprintf(fileName, "temp-db-subset-file%d.bin", join);
        file.Open(0, fileName);
        
        int pageCount = 0;
        bool lastPage = 0;
        int counter = 0;
        
        while (true) {
           //cout << "remove right" << endl;
           if (firstRun) {
                sortedLPipe->Remove(&leftRec);
                sortedRPipe->Remove(&rightRec);
           } else {
               if (lastRecordsMatched || leftGreater) {
                   if (sortedRPipe->Remove(&rightRec) == 0) {
                       break;
                   }
               } else {
                   //Remove left record.
                   if (!leftAlreadyRemoved) {
                       if (sortedLPipe->Remove(&leftRec) == 0) {
                           break;
                        }
                   }
               }
           }
           
           firstRun = false;
           
              //Construct the joinAttributes.
            int leftNumAtts = leftRec.GetNumOfAttributes();
            int rightNumAtts = rightRec.GetNumOfAttributes();
            int numJoinAttributes = leftNumAtts + rightNumAtts;
            int *joinAttributes = new int[numJoinAttributes];

            int i;
            int count = 0;
            for(i = 0; i < leftNumAtts; i++) {
                joinAttributes[count++] = i;
            }
            int startOfRightLocation = count;
            for(i = 0;i < rightNumAtts; i++) {
                joinAttributes[count++] = i;
            }
        
           int compareResult = comp.Compare( &leftRec, &leftOrderMaker, &rightRec , &rightOrderMaker);
           if(compareResult == 0) {
                rightPrevRec.Copy(&rightRec);
               lastRecordsMatched = true;
               
               //Add the subset records in a temporary subset file.
                Record rightRecCopy;
                rightRecCopy.Copy(&rightRec);
                if(filePage->Append(&rightRecCopy))
                {
                    lastPage = 1;         
                }
                else
                {    
                    lastPage = 0;
                    file.AddPage(filePage, pageCount);
                    pageCount++;
                    delete filePage;
                    filePage = NULL;
                    filePage = new Page();
                    filePage->Append(&rightRecCopy);
                }
                
               Record joinRecord;
               joinRecord.MergeRecords(&leftRec, &rightRec, leftNumAtts, rightNumAtts, joinAttributes, numJoinAttributes, startOfRightLocation);
                join->outPipe->Insert(&joinRecord);
           } else if (compareResult == 1) {
               leftGreater = true;
           } else {
               leftGreater = false;
           }
           leftAlreadyRemoved = false;
           
           
           if (lastRecordsMatched && comp.Compare( &rightPrevRec, &rightRec , &rightOrderMaker) != 0) {
                leftPrevRec.Copy(&leftRec);
               
               if (lastPage) {
                    file.AddPage(filePage, pageCount); //To add the last page which is not full.
                    pageCount++;
                    delete filePage;
               }
               
               while (sortedLPipe->Remove(&leftRec)) {
                    bool leftRecsEqual = false;
                    if (comp.Compare( &leftPrevRec, &leftRec , &leftOrderMaker) == 0) {
                        leftRecsEqual = true;
                         Record tempRecord;
                        Page page;
                        for (int count = 0; count<file.GetLength()-2; count++) {
                            file.GetPage(&page, count);
                            while (page.GetFirst(&tempRecord) == 1) {
                                Record joinRecord;
                                   joinRecord.MergeRecords(&leftRec, &tempRecord, leftNumAtts, rightNumAtts, joinAttributes, numJoinAttributes, startOfRightLocation);
                               
                                join->outPipe->Insert(&joinRecord); 
                            } 
                        }
                        
                        pageCount = 0;
                    }
                    
                    if (leftRecsEqual) {
                        //do nothing.
                    } else {
                        leftAlreadyRemoved = true;
                        break;
                    }
                    
                    leftPrevRec.Copy(&leftRec);
               }
               lastRecordsMatched = false;
               
               file.Close();
               filePage = new Page();
                file.Open(0, fileName);
                counter++;
                pageCount = 0;
                lastPage = 0;
           
           }
           
        }
         
        file.Close();
        //cout << "matchCount: " << matchCount;
        //cout << "leftCount:: " << leftCount;
        //cout << "rightCount:: " << rightCount;
        delete bigQL;
        delete bigQR;
        
        // remove the temporary file : temp-db-subset-file
        remove(fileName);
}


