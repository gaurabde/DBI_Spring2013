#include "MetaData.h"
#include <stdlib.h>
#include <iostream>
using namespace std;

MetaData::MetaData(OrderMaker om, int runlen)
{

    sortedOrder = om;
    runLength = runlen;
}

MetaData::MetaData() {
}

void MetaData::Print()
{

    cout<<"Order Maker is"<<endl;
    sortedOrder.Print();
    cout<<"Run length is"<<runLength<<endl;
}


