#ifndef PROJECT_H
#define PROJECT_H

#include "Pipe.h"
#include "DBFile.h"
#include "Record.h"
#include "Function.h"
#include "BigQ.h"
#include <iostream>
#include <sstream>


class Project : public RelationalOp {
        private:
                pthread_t thread;
                Pipe* inputPipe;
                Pipe* outputPipe;
                int* attsToKeep;
                int numAttsToKeep;
                int numAttsNow;
                static void* executeWorkerThread(void * ptr);
	public:
                void Run (Pipe &inPipe, Pipe &outPipe, int *keepMe, int numAttsInput, int numAttsOutput);
                void WaitUntilDone ();
                void Use_n_Pages (int n);
                        
};
#endif
