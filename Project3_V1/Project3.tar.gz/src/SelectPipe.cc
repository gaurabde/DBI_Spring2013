#include "RelationalOp.h"
#include "stdlib.h"
#include "SelectPipe.h"

//Select Pipe functions.
void SelectPipe::Run (Pipe &inPipe, Pipe &outPipe, CNF &selOp, Record &literal) {
    inputPipe = &inPipe;
    outputPipe = &outPipe;
    selOperation = &selOp;
    recLiteral = &literal;        
    pthread_create (&thread, NULL, &executeWorkerThread, (void*)this);
}
void* SelectPipe::executeWorkerThread(void * ptr){       
    SelectPipe* SP = reinterpret_cast<SelectPipe*> (ptr);
    ComparisonEngine comp;
    Record tempRecord;
    while(SP->inputPipe->Remove(&tempRecord)){  
          if(comp.Compare( &tempRecord, SP->recLiteral , SP->selOperation))
                SP->outputPipe->Insert(&tempRecord);            
    }
    SP->outputPipe->ShutDown();
} 

void SelectPipe::WaitUntilDone () {
	pthread_join (thread, NULL);
}

void SelectPipe::Use_n_Pages (int runlen) {

}

