

#ifndef SORTINFO_H
#define	SORTINFO_H

#include "Comparison.h"
#include "ComparisonEngine.h"

class SortInfo {
public:
    OrderMaker *sortOrder;
    int runLength;
};

#endif

