

#include "SortedFile.h"

#include "DBFile.h"
#include "MetaData.h"
using namespace std;

SortedFile::SortedFile () {        
    currentMode = 'R';
}

void SortedFile::InitSortInfo(){
    this->sortOrder = & (metadata.sortedOrder);
    this->runLength = metadata.runLength;
    //this->sortOrder->Print();
}

int SortedFile::Create(char *file_path) {
    int returnVal = 1;
    try {
        this->fileName = file_path;
        file.Open(0, file_path);
    } catch (int e) {
        returnVal = 0;
        cout << "Could not create file. Error code: " << e;
    }
    cout << "Sorted File Created.";
    return returnVal;
}

int SortedFile::Open(char *file_path) {
    int returnVal = 1;
    try {
        this->fileName = file_path;
        cout << "File Path: " << file_path << endl;
        file.Open(1, file_path);
    } catch (int e) {
        returnVal = 0;
        cout << "Could not create file. Error code: " << e;
    }
    return returnVal;
}

int SortedFile::Close() {    
    if (this->currentMode == 'W'){        
        mergeNewRecords();
    }
    file.Close();
}


void SortedFile::Load (Schema &mySchema, char *loadpath) {
    schema = &mySchema;    
    FILE* tableFile = fopen(loadpath, "r");
    Record *addMe = new Record();
    
    inputPipe = new Pipe(1000);
    outputPipe = new Pipe(1000);
    while(addMe->SuckNextRecord(&mySchema, tableFile))	
    {
        inputPipe->Insert(addMe);        
    }
    inputPipe->ShutDown();
    
    bigQ = new BigQ(*inputPipe, *outputPipe, *sortOrder, runLength);
    
    //cout << "in load...............2" << endl;
    
    currentPageNum = 0;
    //Record temp;
    currentPage = new Page();
    bool pageSaved = false;

    int i = 0;
    Record rec[2];
    Record *last = NULL, *prev = NULL;
    
    while(outputPipe->Remove(&rec[i%2]))
    {
        
        prev = last;
	last = &rec[i%2];

        if(prev && last){
               //cout << "in load...............3" << endl;
                //prev->Print(&mySchema);
                pageSaved = false;
                if(!currentPage->Append(prev))
                {
                    pageSaved = true;
                    file.AddPage(currentPage, currentPageNum);
                    currentPage->EmptyItOut();
                    currentPage->Append(prev);
                    currentPageNum++;
                }

        }
        i++;
      }
    
        
   if(!pageSaved)
        file.AddPage(currentPage, currentPageNum);
    
    fclose(tableFile);
    delete outputPipe;
    delete inputPipe;
}


void SortedFile::Add (Record &rec) {
    /*cout << "Inside Add :: " << endl;
    this->sortOrder->Print();
    cout << "  ===================================" <<endl;
    */
    if (currentMode == 'R') {
        //cout << "current mode: " << currentMode;
        inputPipe = new Pipe(1000);
        outputPipe = new Pipe(1000);
        bigQ = new BigQ(*inputPipe, *outputPipe, *sortOrder, runLength);
        currentMode = 'W';
    }
    //cout << "Print rec: " << endl;
    //rec.Print(schema);
    inputPipe->Insert(&rec);
    //cout<<"Changing mode from Read to Write"<<endl;
    
}

void SortedFile::mergeNewRecords () {
    currentMode = 'R';
    if (this->bigQ == NULL) {        
        return;
    }
    
    //cout << "merged recs" << endl;
    inputPipe->ShutDown();
    Record pipeRecords;
    Record fileRecords;
    Pipe &outPipe = *outputPipe;
    int records = 0;
    ComparisonEngine comp;
    Page tempPage;
    int pageCount = 0;
    
    this->MoveFirst();
    
    File tempFile;
    tempFile.Open(0, "temp-merged-db-file.bin");
    
    int pipeResult = outPipe.Remove(&pipeRecords);
    int fileResult = this->GetNext(fileRecords);
    Record mergedRec;
    while (pipeResult && fileResult) {
        int result = comp.Compare(&pipeRecords, &fileRecords, this->sortOrder);
        if (result < 0) {
            mergedRec.Copy(&pipeRecords);
            pipeResult = outPipe.Remove(&pipeRecords);
        } else {
            mergedRec.Copy(&fileRecords);
            fileResult = this->GetNext(fileRecords);
        }
        records++;
        if (!tempPage.Append(&mergedRec)) {
            tempFile.AddPage(&tempPage, pageCount);
            tempPage.EmptyItOut();
            tempPage.Append(&mergedRec);
            pageCount++;
        }
    }
    if (pipeResult || fileResult) {
        if (fileResult) {
            mergedRec.Copy(&fileRecords);
        }
        if (pipeResult) {
            mergedRec.Copy(&pipeRecords);
        }
        
        records++;
        if (!tempPage.Append(&mergedRec)) {
            tempFile.AddPage(&tempPage, pageCount); 
            pageCount++;
            tempPage.EmptyItOut();
            tempPage.Append(&mergedRec); 
        }
    }
    
    copyDataFromPipe(outPipe , records , tempPage, pageCount , tempFile);
    copyDataFromFile(records , tempPage,pageCount , tempFile);
    
    if (records > 0) {
        tempFile.AddPage(&tempPage, pageCount);
    }
    tempFile.Close();
    this->file.Close();

    if (remove(this->fileName)) {
        //cout << "File removed " << endl;
    }
    if (rename("temp-merged-db-file.bin", this->fileName)) {
        //cout << "File renamed " << endl;
    }

    this->file.Open(1, this->fileName);
    
    delete this->bigQ;
    delete this->inputPipe;
    delete this->outputPipe;
    this->bigQ = NULL;
    this->inputPipe = NULL;
    this->outputPipe = NULL;

    this->MoveFirst(); 
}

void SortedFile::copyDataFromPipe(Pipe &outPipe , int &records , Page &tempPage, int &pageCount , File &tempFile){
    Record pipeRecords;
    while (outPipe.Remove(&pipeRecords))
    {
        records++;
        if (!tempPage.Append(&pipeRecords)) {
            tempFile.AddPage(&tempPage, pageCount); 
            pageCount++;
            tempPage.EmptyItOut();
            tempPage.Append(&pipeRecords); 
        }
    }
}

void SortedFile::copyDataFromFile(int &records , Page &tempPage, int &pageCount , File &tempFile){
    Record fileRecords;
    while (this->GetNext(fileRecords)) {
        records++;
        if (!tempPage.Append(&fileRecords)) {
            tempFile.AddPage(&tempPage, pageCount);
            pageCount++;
            tempPage.EmptyItOut();
            tempPage.Append(&fileRecords);
        }
    }
}

void SortedFile::MoveFirst () { 
    if (this->currentMode == 'W') {     
        mergeNewRecords();
    }
    currentPage = new Page();
    if (!this->file.GetLength()) {        
        currentPage->EmptyItOut();
    } else {                
        file.GetPage(currentPage,0);
    }    
    this->currentPageNum = 0;
}

int SortedFile::GetNext (Record &fetchme) {    
    if(this->currentMode == 'W'){
        mergeNewRecords();
    }    
    if(file.GetLength() == 0){        
        return 0;
    }    
    int retVal = currentPage->GetFirst(&fetchme);
    if(retVal ==0){        
         // load next page if available       
            if(currentPageNum < file.GetLength()-2){
                // get the next Page
                delete currentPage;
                currentPage = new Page;
                file.GetPage(currentPage , ++currentPageNum);                               
                retVal = currentPage->GetFirst(&fetchme);
            }
    }
    return retVal;
}



int SortedFile::GetNext(Record &fetchme, CNF &cnf, Record &literal) {
    ComparisonEngine comp;
    Record rec;

    // Check whether the file has further records
    if (this->GetNext(rec) == 0)
        return 0;
    
    // Check if the First record matches the given CNF
    if (comp.Compare(&rec, &literal, &cnf)) {
        fetchme.Consume(&rec);
        return 1;
    }
    
    OrderMaker inputOrderMaker;
    bool success = cnf.GetQueryOrderMaker(*this->sortOrder, inputOrderMaker);
    
    if (success) {
        return this->PerformBinarySearch(fetchme, cnf, literal, &inputOrderMaker);
    }else{
        return this->PerformSequentialSearch(fetchme, cnf, literal);
    }
}

int SortedFile::PerformSequentialSearch(Record &fetchme, CNF &cnf, Record &literal) {    
    ComparisonEngine comp;
        
    while (this->GetNext(fetchme)) {
        //if compare is true, we found the record
        if (comp.Compare(&fetchme, &literal, &cnf)) {            
            return 1;
        }
    }    
    return 0;
}


int SortedFile::PerformBinarySearch(Record &fetchme, CNF &cnf, Record &literal,OrderMaker* inputOrderMaker) {    
    Page tempPage;
    Record tempRec;
    ComparisonEngine comp;
    int fileLength = this->file.GetLength() - 2;
    int leftPagePtr = this->currentPageNum;    
    int rightPagePtr = fileLength;
    int midPagePtr = 0;
    
    int compResult = 0;
   
    while (leftPagePtr <= rightPagePtr) {
        midPagePtr = (leftPagePtr + rightPagePtr) / 2;
        this->file.GetPage(&tempPage, midPagePtr);        
        tempPage.GetFirst(&tempRec);
        compResult = comp.Compare(&literal, inputOrderMaker, &tempRec, this->sortOrder);
        if(compResult > 0){
            leftPagePtr = midPagePtr + 1;
        }else{
            // Check if both the midPage & rightPage point to the same page Number
            if (compResult==0 && (midPagePtr == rightPagePtr)){ 
                break;
            }
            rightPagePtr = midPagePtr - 1;
        }
    }
    
     // Check if the currentPage Number is greater than the right pointer
    if (rightPagePtr < this->currentPageNum) {           
        return 0;
    }
    
    //check if we need to get new page
    if (rightPagePtr != this->currentPageNum) {
        this->currentPageNum = rightPagePtr;
        this->file.GetPage(this->currentPage, rightPagePtr);
    }
  
    //Move the record pointer sequentially till we reach the required data
    if(moveSequentialDataPointer(fetchme, cnf, literal, inputOrderMaker) == 1){
        return 1;
    }
    
    // Failure point of Binary Search
    this->currentPageNum = this->file.GetLength() - 2;
    this->currentPage->EmptyItOut();
    return 0;
}

int SortedFile::moveSequentialDataPointer(Record &fetchme, CNF &cnf, Record &literal,OrderMaker* inputOrderMaker){
    Record tmpRecord;
    ComparisonEngine comp;
    int compResult = 0;
    int compResult2 = 0;
    
    // search till we get a result that matches the provided CNF
     while (compResult = this->GetNext(tmpRecord)){
         // Check if the fetched Record is less than or equal to the CNF
         compResult2 = comp.Compare(&literal, inputOrderMaker, &tmpRecord, this->sortOrder);
         if(compResult2 <= 0){
             break;
         }
     }
    
    if (compResult && (compResult2==0) && comp.Compare(&tmpRecord, &literal, &cnf)) {
        fetchme.Consume(&tmpRecord);
        return 1;
    }
    
    while (this->GetNext(tmpRecord) && comp.Compare(&literal, inputOrderMaker, &tmpRecord, this->sortOrder)==0){
        
        if (compResult && (compResult2==0) && comp.Compare(&tmpRecord, &literal, &cnf)) {
                fetchme.Consume(&tmpRecord);
                return 1;
        }
    }

    return 0;
}
