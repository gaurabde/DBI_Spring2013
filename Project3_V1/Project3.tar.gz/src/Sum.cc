#include "RelationalOp.h"
#include "stdlib.h"
#include "Sum.h"


void Sum::Run (Pipe &inPipe, Pipe &outPipe, Function &computeMe){
    this->inputPipe = &inPipe;
    this->outputPipe = &outPipe;
    this->sumFunction = &computeMe;
    pthread_create (&thread, NULL, &executeWorkerThread, (void*)this);    
}

void* Sum::executeWorkerThread(void * ptr){       
    Sum* sum = reinterpret_cast<Sum*> (ptr);
    Record rec;    
    long long int intSum = 0;
    long double doubleSum = 0;
    
    int res;
    double doubleRes;
    Type resultType;
        
    while(sum->inputPipe->Remove(&rec)){
        resultType = sum->sumFunction->Apply(rec , res , doubleRes);        
        intSum += res;
        doubleSum += doubleRes;
    }
    
    // Create a new schema containing the sum as the only attribute
    
    Attribute attr;
    attr.myType = resultType;
    attr.name = "Sum";
    Schema out_sch ("out_sch", 1, &attr);        
    Record outputRecord;
    char sumOutput[100];
        
    switch(resultType){
        case Int : 
            sprintf(sumOutput , "%lld|" , intSum);
            break;
        case Double :
            sprintf(sumOutput , "%Lf|" , doubleSum);
            break;
        default:
            cout << "Invalid data type" <<endl;
            return NULL;
    }
    
    outputRecord.ComposeRecord(&out_sch , sumOutput); 
    sum->outputPipe->Insert(&outputRecord);  
    sum->outputPipe->ShutDown();
} 

void Sum::WaitUntilDone () {
	pthread_join (thread, NULL);
}
void Sum::Use_n_Pages (int n){
   // to be implemented
}
