#ifndef SUM_H
#define SUM_H

#include "Pipe.h"
#include "DBFile.h"
#include "Record.h"
#include "Function.h"
#include "BigQ.h"
#include <iostream>
#include <sstream>
class Sum : public RelationalOp {
        private:
                pthread_t thread;
                Pipe* inputPipe;
                Pipe* outputPipe;
                Function* sumFunction;
                static void* executeWorkerThread(void * ptr);
	public:
                void Run (Pipe &inPipe, Pipe &outPipe, Function &computeMe);
                void WaitUntilDone ();
                void Use_n_Pages (int n);
                
};
#endif
