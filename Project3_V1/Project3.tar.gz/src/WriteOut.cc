#include "RelationalOp.h"
#include "stdlib.h"
#include "WriteOut.h"

void WriteOut::Run (Pipe &inPipe, FILE *outFile, Schema &mySchema){
    this->inputPipe = &inPipe;
    this->outputFile = outFile;
    this->schema = &mySchema;
    pthread_create (&thread, NULL, &executeWorkerThread, (void*)this);
}

void* WriteOut::executeWorkerThread(void * ptr){
   WriteOut* WO = reinterpret_cast<WriteOut*> (ptr);
   Record rec;
   int totalRecs = 0;
   while(WO->inputPipe->Remove(&rec)){
       totalRecs ++;
       rec.PrintRecordToFile(WO->schema , WO->outputFile);
   }
   cout << "Total Records Written in the File :: " << totalRecs << endl;
}

void WriteOut::WaitUntilDone(){
     pthread_join (thread, NULL);
}

void WriteOut::Use_n_Pages (int n){
    
}


