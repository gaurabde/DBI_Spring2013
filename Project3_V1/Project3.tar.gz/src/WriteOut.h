#ifndef WRITEOUT_H
#define WRITEOUT_H

#include "Pipe.h"
#include "DBFile.h"
#include "Record.h"
#include "Function.h"
#include "BigQ.h"
#include <iostream>
#include <sstream>

class WriteOut : public RelationalOp {
        private :
                pthread_t thread;
                Pipe* inputPipe;
                FILE* outputFile;
                Schema* schema;
                static void* executeWorkerThread(void * ptr);
	public:
                void Run (Pipe &inPipe, FILE *outFile, Schema &mySchema);
                void WaitUntilDone();
                void Use_n_Pages (int n);
};

#endif
