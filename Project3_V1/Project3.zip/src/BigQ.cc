#include "BigQ.h"
#include "Record.h"
#include <algorithm>

BigQ :: BigQ (Pipe &in, Pipe &out, OrderMaker &sortorder, int runlen) :inputPipe(&in), outputPipe(&out){
    order = &sortorder;    
    this->runlength = runlen;
    pthread_t threadId;
    
    pthread_create (&threadId, NULL, &executeWorkerThread, (void*)this);
}

BigQ :: BigQ (Pipe &in, Pipe &out, OrderMaker &sortorder, int runlen, bool val) :inputPipe(&in), outputPipe(&out){
    order = &sortorder;    
    this->runlength = runlen;
    pthread_t threadId;    
    pthread_create (&threadId, NULL, &executeWorkerThread, (void*)this);
    pthread_join (threadId, NULL);
}

void* BigQ::executeWorkerThread(void * ptr)
{
    BigQ* bigQ = reinterpret_cast<BigQ*> (ptr);
    bigQ->pageCount = 0;
    bigQ->runPages = new vector<int>;
    bigQ->runPages->push_back(0);    
    sprintf(bigQ->tempFileName, "temp-db-file%d.bin", bigQ);
    bigQ->generateRuns();
    bigQ->mergeRecords();
    bigQ->outputPipe->ShutDown();
    //cout << "out Pipe stop" << endl;
}

BigQ::~BigQ () {
    runPages->clear();
    delete runPages;
    //remove the temp file.
    remove(this->tempFileName);
}

void BigQ :: generateRuns() {
    int recCount = 0;
    //Read the records into pages and check whether
    Record *tempRecord = new Record();
    
    Page pages[runlength];
    Record* leftoverRecord;
    bool leftover = false;
    int count = 0;
    for (count = 0; count < runlength; count++) {
        pages[count].EmptyItOut();
    }
    
    int counter = 0;
    bool runFull = false;
    
    while (inputPipe->Remove(tempRecord)) {
        recCount++;
        if (pages[counter].Append(tempRecord) == 1) {
            runFull = false;    
            
        }
        else {
            counter++;
            if (counter < runlength){
                pages[counter].Append(tempRecord);                
            }else{
                leftoverRecord = tempRecord;
                leftover = true;
            }
        }
        
        if (counter == runlength) {
            runCount++;
            runFull = true;
            doSorting(pages);
            
        //Write to disk here and then empty out the pages.
            for (count = 0; count < runlength; count++) {
                pages[count].EmptyItOut();
            }
            
            if(leftover)
                pages[0].Append(leftoverRecord);
            
            leftover = false;
            counter = 0;
        }
        
    }
    
    if (!runFull) {
        runCount++;
        doSorting(pages);
    }
      
    delete tempRecord;  
}

void BigQ :: doSorting(Page pages[]) {
    int totalNoOfRecords = 0;
    for (int count = 0; count < runlength; count++) {
            totalNoOfRecords = totalNoOfRecords + pages[count].getNumberOfRecords();
    }

    Record **records = new Record*[totalNoOfRecords];
    Record *removedRecord ;
    int recordCount = 0;
                
    for (int loopCount = 0; loopCount < runlength; loopCount++) {
        removedRecord = new Record();
        while((recordCount < totalNoOfRecords) && (pages[loopCount].GetFirst(removedRecord) == 1))
            {
                records[recordCount] = removedRecord;
                recordCount++;
                removedRecord = new Record();              
            }
        delete removedRecord;
    }

    sort(records, records + totalNoOfRecords, CompareRecords(order , true));
    
    Page* filePage = new Page();
    File file;
    
    if(pageCount == 0) {        
        file.Open(0, this->tempFileName);
    } else {
        file.Open(1, this->tempFileName);
    }
    
    int fileRecordCount = 0;
    bool lastPage = 0;
    while(fileRecordCount < totalNoOfRecords)
    {
        if(filePage->Append(records[fileRecordCount]))
        {
            lastPage = 1;
            fileRecordCount++;           
        }
        else
        {
            lastPage = 0;            
            file.AddPage(filePage, pageCount);
            pageCount++;
            delete filePage;
            filePage = NULL;
            filePage = new Page();
        }
    }
    
        
    if (lastPage) {
    	//To add the last page which is not full.
        file.AddPage(filePage, pageCount);
        pageCount++;
        delete filePage;
    }
    
    runPages->push_back(pageCount);
    file.Close();
        
   // once the records have been writen in the array free the memory allocated to Record pointers
    for (int delCount=0; delCount<totalNoOfRecords; delCount++) {
       delete records[delCount];
    }
    delete [] records;
}


void BigQ :: mergeRecords(){
    int totalRuns = runPages->size(); // This is the total size of the runs        
    int currPageNumsInRun[totalRuns]; // This array contains the current processing page of each run
    Page* pagePointers[totalRuns]; // This array contains the Page pointers
    
    int count = 0;
    // This loop initializes the currPageNumsInRun array to the first page of each run
    for( count = 0 ; count < totalRuns ; count++){      
        currPageNumsInRun[count] = (*runPages)[count];
    }
            
    File file;
    file.Open(1, this->tempFileName);
    
    // This is the priority queue that contains heads of all the runs
    priority_queue<Record* , vector<Record*> , CompareRecords> pQueue (CompareRecords(this->order , false));
    
    // This loop puts the heads of all the runs in the priority queue
    for( count = 0 ; count < totalRuns-1 ; count++){
        Page* page = new Page();
        file.GetPage(page,(*runPages)[count]);
        pagePointers[count] = page; 
        
        Record* headRecord = new Record();
        page->GetFirst(headRecord);
        
        // Set the run number in the head record & push it in the Queue
        headRecord->setRunNum(count);
        pQueue.push(headRecord);        
    }
   
    int runNum = 0;
    bool hasRecord = true;
    int oldPageNum = 0;
    int pageLimit = 0;
    
    // Loop till the priority Queue becomes empty
    while(!pQueue.empty()){ 
        // Get the minimum element from the queue & insert it into the pipe
        Record* r = pQueue.top();
        
        pQueue.pop();
        runNum = r->getRunNum();
        //cout << "Inserting into out pipe" << endl;
        //r->Print(schema);
        outputPipe->Insert(r);
                
        delete r;
        
        // check to which run the record belongs...and get next record from that run       
        Record* temp = new Record();        
        hasRecord = true;
        if(pagePointers[runNum]->GetFirst(temp) != 1){
            // reached end of page...move to the next one
            hasRecord = false;
            oldPageNum = currPageNumsInRun[runNum];
            pageLimit = (*runPages)[runNum+1];

          // Check whether the current run has utilized all the pages, it is empty
            if(oldPageNum+1 < pageLimit){
                currPageNumsInRun[runNum] = oldPageNum+1;
                pagePointers[runNum]->EmptyItOut();
                
                // Get the new Page in the pagePointer
                file.GetPage(pagePointers[runNum] , currPageNumsInRun[runNum]);
                if(pagePointers[runNum]->GetFirst(temp) == 1){
                    hasRecord = true;
                }
            }            
        }
        
        // If the current run has any records then add them to the queue
        if(hasRecord){            
            temp->setRunNum(runNum);
            pQueue.push(temp);                        
        }else{
            // free the memory that was allocated to the record object as it is unused
            delete temp;
        }                
    }   
    file.Close();
    
    // Clean up resources
    for( count = 0 ; count < totalRuns-1 ; count++){
        delete pagePointers[count];
    }
}
