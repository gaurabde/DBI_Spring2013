#include "TwoWayList.h"
#include "Record.h"
#include "Schema.h"
#include "File.h"
#include "Comparison.h"
#include "ComparisonEngine.h"
#include "DBFile.h"
#include "Defs.h"
#include "GenericDBFile.h"
#include <iostream>
#include "string.h"
#include <fstream>
#include "SortedFile.h"
#include "HeapFile.h"
#include "MetaData.h"

// stub file .. replace it with your own DBFile.cc

DBFile::DBFile() {

}

int DBFile::Create(char *fileName, fType f_type, void *startup) {
	char *intialPath = new char[50];
	strcpy(intialPath, fileName);
	strcat(fileName, ".metadata");
	fstream fileObject(fileName, fstream::out | fstream::binary);

	if (f_type == 0) {
		genericDBFile = new HeapFile();
		fileObject.write((char*) ("heap"), 4);

		fileObject.close();

	} else {
		MetaData newMetaData(*(((SortInfo*) startup)->sortOrder),
				((SortInfo*) startup)->runLength);
		fileObject.write((char *) (&newMetaData), sizeof(newMetaData));
		genericDBFile = new SortedFile();
		fileObject.close();

		// Load metadata
		fstream fileObjectRead(fileName, fstream::in | fstream::binary);
		fileObjectRead.read((char *) &(genericDBFile->metadata),
				sizeof(genericDBFile->metadata));

		genericDBFile->InitSortInfo();
		fileObjectRead.close();

	}

	strcpy(fileName, intialPath);

	genericDBFile->fileName = intialPath;
	int returnValue = genericDBFile->Create(intialPath);

	return returnValue;
}

void DBFile::Load(Schema &f_schema, char *loadpath) {
	genericDBFile->Load(f_schema, loadpath);
}

int DBFile::Open(char *fileName) {
	int returnValue = 1;
	try {
		char *intialPath = new char[50];
		strcpy(intialPath, fileName);
		strcat(fileName, ".metadata");

		//Check the type of the file.
		fstream fileObject(fileName, fstream::in | fstream::binary);
		char type[4];

		if (type == "heap") {
			genericDBFile = new HeapFile();
		} else {
			SortInfo *sortInfo = new SortInfo();

			genericDBFile = new SortedFile();
			fileObject.read((char *) &(genericDBFile->metadata),
					sizeof(genericDBFile->metadata));

			genericDBFile->InitSortInfo();
		}

		fileObject.close();
		strcpy(fileName, intialPath);
		returnValue = genericDBFile->Open(intialPath);
		this->MoveFirst();
	} catch (int e) {
		cout << "File open Error: \t" << e;
		returnValue = 0;
	}

	return returnValue;
}

void DBFile::MoveFirst() {
	genericDBFile->MoveFirst();
}

int DBFile::Close() {
	genericDBFile->schema = this->schema;
	genericDBFile->Close();
}

void DBFile::Add(Record &rec) {
	genericDBFile->schema = this->schema;
	genericDBFile->Add(rec);
}

int DBFile::GetNext(Record &fetchme) {
	return genericDBFile->GetNext(fetchme);
}

int DBFile::GetNext(Record &fetchme, CNF &cnf, Record &literal) {

	return genericDBFile->GetNext(fetchme, cnf, literal);
}
