#ifndef DUP_REM_H
#define DUP_REM_H

#include "Pipe.h"
#include "DBFile.h"
#include "Record.h"
#include "Function.h"
#include "BigQ.h"
#include <iostream>
#include <sstream>


class DuplicateRemoval : public RelationalOp {
        private:
                pthread_t thread;
                int pages;
                Pipe* inputPipe;
                Pipe* outputPipe;
                Schema* schema;
                static void* executeWorkerThread(void * ptr);
	public:
                DuplicateRemoval();
                void Run (Pipe &inPipe, Pipe &outPipe, Schema &mySchema) ;
                void WaitUntilDone ();
                void Use_n_Pages (int n) ;
};

#endif
