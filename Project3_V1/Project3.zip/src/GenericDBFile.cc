#include "GenericDBFile.h"

int GenericDBFile::Create (char *fpath) {
    
}

int GenericDBFile::Open (char *fpath) {
    
}

int GenericDBFile::Close () {
    
}

void GenericDBFile::Load (Schema &myschema, char *loadpath) {
    
}

void GenericDBFile::MoveFirst () {
    
}

void GenericDBFile::Add (Record &addme) {
    
}

int GenericDBFile::GetNext (Record &fetchme) {
    
}

int GenericDBFile::GetNext (Record &fetchme, CNF &cnf, Record &literal) {
    
}

    void GenericDBFile::InitSortInfo(){
        
    }