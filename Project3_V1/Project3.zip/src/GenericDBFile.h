
#include "Schema.h"
#include "Record.h"
#include "SortInfo.h"
#include "MetaData.h"

#ifndef GENERICDBFILE_H
#define	GENERICDBFILE_H

class GenericDBFile {
public:
    virtual int Create (char *fpath);
    virtual int Open (char *fpath);
    virtual int Close ();
    virtual void Load (Schema &myschema, char *loadpath);
    virtual void MoveFirst ();
    virtual void Add (Record &addme);
    virtual int GetNext (Record &fetchme);
    virtual int GetNext (Record &fetchme, CNF &cnf, Record &literal);
    virtual  void InitSortInfo();
    char *fileName;
    Schema *schema;

    MetaData metadata;
};


#endif

