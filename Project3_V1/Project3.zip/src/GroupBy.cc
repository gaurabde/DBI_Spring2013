#include "RelationalOp.h"
#include "stdlib.h"
#include "GroupBy.h"


GroupBy::GroupBy(){
    this->pages = 25;
}

void GroupBy::Run (Pipe &inPipe, Pipe &outPipe, OrderMaker &groupAtts, Function &computeMe){
    this->inputPipe = &inPipe;
    this->outputPipe = &outPipe;
    this->groupByAtts = &groupAtts;
    this->sumFunction = &computeMe;
    pthread_create (&thread, NULL, &executeWorkerThread, (void*)this);
}

void* GroupBy::executeWorkerThread(void * ptr){
   GroupBy* GB = reinterpret_cast<GroupBy*> (ptr); 
   Pipe sortedPipe(100);
   
   // sort the incoming tuples
   BigQ* bigQ = new BigQ(*(GB->inputPipe), sortedPipe, *GB->groupByAtts , GB->pages);   
   long long int intSum = 0;
   long double doubleSum = 0;
   int res = 0;
   double doubleRes = 0;
   Type resultType;
   Record rec ,prevRec;
   ComparisonEngine compEng;
   
   int numOfAttsToKeep = GB->groupByAtts->numAtts + 1;
   int attsToKeep[numOfAttsToKeep];
   attsToKeep[0] = 0;
   
   for(int indx = 0 ; indx < GB->groupByAtts->numAtts ; indx++){
       attsToKeep[indx+1] = GB->groupByAtts->whichAtts[indx];
   }
         
   if(sortedPipe.Remove(&prevRec)){       
       resultType = GB->sumFunction->Apply(prevRec , res , doubleRes);
       intSum = res;
       doubleSum = doubleRes;
   }
      
   // Attributes of the new tables
   Attribute attr;
   attr.myType = resultType;
   attr.name = "Sum";
   Schema out_sch ("out_sch", 1, &attr);
   Record sumRecord ,outputRecord;
   char sumOutput[100];

   while(sortedPipe.Remove(&rec)){      
      
       /* if the records are equal then compute the sum        
        else push the new record into the output pipe and update the prev record
        */       
       resultType = GB->sumFunction->Apply(rec , res , doubleRes);
       if(compEng.Compare(&rec, &prevRec, GB->groupByAtts) == 0){
           // if tuples are equal then simple compute the sum           
           intSum += res;
           doubleSum += doubleRes;           
       }else{
           //push the output & sum to the pipe           
           GB->generateSumRecord(resultType , &intSum , &doubleSum , sumOutput , &sumRecord , &out_sch);           
           outputRecord.MergeRecords(&sumRecord , &prevRec , 1 , prevRec.GetNumOfAttributes() , attsToKeep , numOfAttsToKeep  , 1);           
           GB->outputPipe->Insert(&outputRecord);
           
           // compute the sumFunction for the new record           
           intSum = res;
           doubleSum = doubleRes;          
           prevRec.Copy(&rec);         
       }       
   }
   // Generate the output record for the last group by value
   GB->generateSumRecord(resultType , &intSum , &doubleSum , sumOutput , &sumRecord , &out_sch); 
   outputRecord.MergeRecords(&sumRecord , &prevRec , 1 , prevRec.GetNumOfAttributes() , attsToKeep , numOfAttsToKeep  , 1);
   GB->outputPipe->Insert(&outputRecord);   
   GB->outputPipe->ShutDown();
   delete bigQ;
}
void GroupBy::generateSumRecord(Type& resultType , long long int* intSum , long double* doubleSum , char* sumOutput , Record* sumRecord ,  Schema* outputSchema){
    switch(resultType){
        case Int : 
                sprintf(sumOutput , "%lld|" , *intSum);
                break;
        case Double :
                sprintf(sumOutput , "%Lf|" , *doubleSum);
                break;
    }
    sumRecord->ComposeRecord(outputSchema , sumOutput);
}

void GroupBy::WaitUntilDone () { 
    pthread_join (thread, NULL);
}
void GroupBy::Use_n_Pages (int n) { 
    this->pages = n;
}
