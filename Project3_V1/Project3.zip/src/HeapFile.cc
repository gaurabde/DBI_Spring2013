#include "HeapFile.h"

HeapFile::HeapFile() {
    
}

int HeapFile::Create (char *file_path) {
    int returnVal = 1;
    try {
        this->fileName = file_path;
        file.Open(0, file_path);
    } catch (int e) {
        returnVal = 0;
    }
    return returnVal;
}

int HeapFile::Open (char *file_path) {
    int returnVal = 1;
    try {
        this->fileName = file_path;
        file.Open(1, file_path);
    } catch (int e) {
        returnVal = 0;
    }
    return returnVal;
}

int HeapFile::Close () {
    file.Close();
}

void HeapFile::Load (Schema &myschema, char *loadpath) {
    FILE *tableFile = fopen (loadpath, "r");
     Record temp;
    Page pageObj;
    
    //We empty out the page contents since for a heap file implementation only one instance of Page is to be used.
    
    int pageCounter = 0;
    bool pageSaved = false;

    while (temp.SuckNextRecord (&myschema, tableFile) == 1) {
            int fitPossible = pageObj.Append(&temp);
	    pageSaved = false;
            if (fitPossible != 1) {
                file.AddPage(&pageObj, pageCounter);
                pageSaved = true;
                pageObj.EmptyItOut();
                pageObj.Append(&temp);
                pageCounter++;
            }
        }
	if(!pageSaved)
                 file.AddPage(&pageObj, pageCounter);
}

void HeapFile::MoveFirst () {
    Page pageObj;
    file.GetPage(&pageObj,0);
    currentPageNum = 0;
    pageObj.GetFirst(&currentRecord);
    //cout << "Moved to first Record" << endl;
    currentPage = new Page();
    file.GetPage(currentPage,0);
}

void HeapFile::Add (Record &addme) {
    Page lastPage;  
    Record recCopy;
    recCopy.Copy(&addme);
    int pagePos = file.GetLength()-2;

    if(pagePos >= 0){
        file.GetPage(&lastPage ,pagePos);
    }else{
        pagePos = 0;
    }

    int fitPossible = lastPage.Append(&addme);
    if (fitPossible != 1) {
        lastPage.EmptyItOut();        
        lastPage.Append(&addme);  
        pagePos ++;
    }
    file.AddPage(&lastPage, pagePos);
    
    // Add the record to the current page stored in the DBFile
    if((currentPageNum == pagePos) && (currentPage != 0)){
        currentPage->Append(&recCopy);        
    }
}

int HeapFile::GetNext (Record &fetchme) {
    if(file.GetLength() == 0){
        return 0;
    }
    int retVal = currentPage->GetFirst(&fetchme);
    if(retVal ==0){        
         // load next page if available       
            if(currentPageNum < file.GetLength()-2){
                // get the next Page
                delete currentPage;
                currentPage = new Page;
                file.GetPage(currentPage , ++currentPageNum);                               
                retVal = currentPage->GetFirst(&fetchme);
            }else{
                // next page is not available
            }
    }
    return retVal;
}

int HeapFile::GetNext (Record &fetchme, CNF &cnf, Record &literal) {
    ComparisonEngine comp;
    while(true){
        if(GetNext(fetchme) ==0)
            return 0;

         // Apply the CNF to the records    
          if(comp.Compare( &fetchme, &literal , &cnf))
             return 1;            
    }
}

