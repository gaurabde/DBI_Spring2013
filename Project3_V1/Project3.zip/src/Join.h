#ifndef JOIN_H
#define JOIN_H

#include "Pipe.h"
#include "DBFile.h"
#include "Record.h"
#include "Function.h"
#include "BigQ.h"
#include <iostream>
#include <sstream>


class Join : public RelationalOp { 
        private :
                pthread_t thread;
                Pipe *inPipeL;
                Pipe *inPipeR;
                Pipe *outPipe;
                CNF *selOp;
                Record *literal;
                Schema *leftSchema;
                Schema *rightSchema;
                OrderMaker leftOrderMaker;
                OrderMaker rightOrderMaker;
                Page *blockPage;
                File rightFile;
                int pageCounter;
                int totalNoOfPages;
                bool endOfBlocks;
                bool rightFileCreated;
                bool lastPage;
                int runLength;
                static void* executeWorkerThread(void * ptr);
                void doSortMergeJoin(Join *join);
                void doBlockNestedJoin(Join *join);
                Page* fetchNextBlock(Join *join, Record &lastRecord);
	public:
                Join();
                void Run (Pipe &inPipeL, Pipe &inPipeR, Pipe &outPipe, CNF &selOp, Record &literal);                
                void WaitUntilDone ();
                void Use_n_Pages (int n);
};

#endif
