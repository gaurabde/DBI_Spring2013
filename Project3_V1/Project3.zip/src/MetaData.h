#ifndef _METADATA_H
#define	_METADATA_H

#include "Comparison.h"

class MetaData {
public:

    OrderMaker sortedOrder;
    int runLength;

    MetaData(OrderMaker om, int runLength);
    MetaData();
    void Print();

};

#endif	/* _METADATA_H */

