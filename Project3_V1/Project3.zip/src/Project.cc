#include "RelationalOp.h"
#include "stdlib.h"
#include "Project.h"


//Project functions.
void Project::Run (Pipe &inPipe, Pipe &outPipe, int *keepMe, int numAttsInput, int numAttsOutput) {
    this->inputPipe = &inPipe;
    this->outputPipe = &outPipe;
    this->attsToKeep = keepMe;
    this->numAttsToKeep = numAttsOutput;
    this->numAttsNow = numAttsInput;
    pthread_create (&thread, NULL, &executeWorkerThread, (void*)this);
}

void* Project::executeWorkerThread(void * ptr){       
    Project* project = reinterpret_cast<Project*> (ptr);
    Record tempRecord;
    while(project->inputPipe->Remove(&tempRecord)){
        //Construct output pipe record here.
        tempRecord.Project(project->attsToKeep, project->numAttsToKeep, project->numAttsNow);
        project->outputPipe->Insert(&tempRecord);
    }
    project->outputPipe->ShutDown();
} 

void Project::WaitUntilDone () {
	pthread_join (thread, NULL);
}

void Project::Use_n_Pages(int n) {
    
}

