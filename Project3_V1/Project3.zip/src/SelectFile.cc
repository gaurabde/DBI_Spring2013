

#include "RelationalOp.h"
#include "stdlib.h"
#include "SelectFile.h"

void SelectFile::Run (DBFile &inFile, Pipe &outPipe, CNF &selOp, Record &literal) {    
    dbFile = &inFile;
    outputPipe = &outPipe;
    selOperation = &selOp;
    recLiteral = &literal;        
    pthread_create (&thread, NULL, &executeWorkerThread, (void*)this);    
}

void* SelectFile::executeWorkerThread(void * ptr){       
    SelectFile* SF = reinterpret_cast<SelectFile*> (ptr);
    Record tempRecord;     
    while(SF->dbFile->GetNext(tempRecord , *SF->selOperation , *SF->recLiteral ) == 1) {        
        SF->outputPipe->Insert(&tempRecord);
    }
    SF->outputPipe->ShutDown();
} 

void SelectFile::WaitUntilDone () {
	pthread_join (thread, NULL);
}

void SelectFile::Use_n_Pages (int runlen) {

}

