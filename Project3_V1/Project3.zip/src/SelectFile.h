#ifndef SELECTFILE_H
#define SELECTFILE_H

#include "Pipe.h"
#include "DBFile.h"
#include "Record.h"
#include "Function.h"
#include "BigQ.h"
#include <iostream>
#include <sstream>

class SelectFile : public RelationalOp { 

	private:
                pthread_t thread;
                DBFile* dbFile;
                Pipe* outputPipe;
                CNF* selOperation;
                Record* recLiteral;
                static void* executeWorkerThread(void * ptr);
	
	public:
                void Run (DBFile &inFile, Pipe &outPipe, CNF &selOp, Record &literal);
                void WaitUntilDone ();
                void Use_n_Pages (int n);
                
};
#endif
