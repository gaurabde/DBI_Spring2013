

#ifndef SORTEDFILE_H
#define	SORTEDFILE_H

#include "BigQ.h"
#include "Pipe.h"
#include "DBFile.h"

class SortedFile : public GenericDBFile
{
public:
    SortedFile();
    int Create (char *fpath);
    int Open (char *fpath);
    void Load (Schema &myschema, char *loadpath);
    int Close ();
    void MoveFirst ();
    void Add (Record &addme);
    void InitSortInfo();
    int GetNext (Record &fetchme);
    int GetNext (Record &fetchme, CNF &cnf, Record &literal);
    //Schema *schema;
private:
    char currentMode;
    BigQ *bigQ;
    Pipe *inputPipe;
    Pipe *outputPipe;
    OrderMaker *sortOrder;
    int runLength;
    File file;
    char *fileName;
    Record currentRecord;
    int currentPageNum;
    Page *currentPage;
    void mergeNewRecords();
    int PerformSequentialSearch(Record &fetchme, CNF &cnf, Record &literal);
    int PerformBinarySearch(Record &fetchme, CNF &cnf, Record &literal,OrderMaker* inputOrderMaker);    
    int moveSequentialDataPointer(Record &fetchme, CNF &cnf, Record &literal,OrderMaker* inputOrderMaker);
    void copyDataFromPipe(Pipe &outPipe , int &records , Page &tempPage, int &pageCount , File &tempFile);
    void copyDataFromFile(int &records , Page &tempPage, int &pageCount , File &tempFile);
};

#endif	/* SORTEDFILE_H */

